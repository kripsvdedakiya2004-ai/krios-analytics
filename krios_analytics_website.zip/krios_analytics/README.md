# KRIOS ANALYTICS — website prototype

Open `index.html` in a modern browser.

## Included
- Responsive minimal fintech landing page
- Forex, crypto and commodity watchlist filters
- Illustrative market cards (clearly marked as demo data)
- Analysis workspace placeholder for a licensed chart/data provider
- Position-size and risk/reward calculators
- Browser-local trading journal note demo
- Free and Premium membership presentation
- CEO & Founder: Krips Dedakiya

## Important before public launch
This is a front-end prototype, not a production trading platform. It does not contain live prices, broker connectivity, AI signals, authentication, a database, payment processing or real alert delivery. Replace illustrative quotes with a licensed market-data API; integrate a chart provider; implement secure server-side authentication, database storage, billing and alert infrastructure. Have legal and compliance requirements reviewed for your target markets. Do not market generated analysis as guaranteed signals.

## Quick publish
Upload `index.html` to a static host such as Netlify, Vercel or GitHub Pages. For a production app, deploy a backend separately and keep API keys server-side.
