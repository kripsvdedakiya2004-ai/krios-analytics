# KRIOS ANALYTICS — live-data-ready prototype

## Run locally
1. Install Node.js 20 or newer.
2. Copy `.env.example` to `.env`.
3. Create a Twelve Data account and copy your API key into `.env`:
   `TWELVE_DATA_API_KEY=your_real_key`
4. In this folder run:
   ```bash
   npm install
   npm start
   ```
5. Open http://localhost:3000

The website now requests quotes from its own backend at `/api/markets`. The API key stays on the server and is not sent to the browser. The server caches quotes for 15 minutes by default to control API usage.

## Important provider and licensing notes
- No live feed can connect until you add your own valid Twelve Data API key.
- Twelve Data's current Basic plan lists real-time forex and crypto, but does not list commodities market data. Commodities require an eligible plan/add-on.
- The individual Grow plan currently lists commodities and internal display; that is not automatically permission to publicly redistribute prices on a commercial website. KRIOS ANALYTICS is a public-facing business, so confirm the commercial/external-display licence with Twelve Data before showing data to visitors.
- Check symbol availability for XAU/USD and XAG/USD in your account's symbol catalog. Broker CFD symbols may differ.
- The browser refreshes every 15 minutes. Adjust `CACHE_SECONDS` only after checking your API quota and data licence.
- The quotes endpoint is used for latest quote data. For true streaming, implement a licensed WebSocket plan and server-side fan-out.
- The displayed percentage change depends on fields supplied by the provider. If unavailable, the UI says change unavailable.

## Included
- Forex, crypto and commodities watchlist
- Server-side Twelve Data quote proxy
- API-key protection via environment variable
- Server-side caching
- Existing calculators and trading journal
- CEO & Founder: Krips Dedakiya

This is still a prototype. It does not include authentication, billing, broker execution, or AI-generated analysis. Do not present illustrative/demo analysis as investment advice.
